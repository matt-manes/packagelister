# Changelog

## 1.1.2 (2023-02-04)

#### Fixes

* (cli): change == to ~= when generating requirements.txt


## v1.1.1 (2023-01-25)

#### Fixes

* pyproject.toml indentation issue
#### Others

* build 1.1.1 dist files
* (cli): change abbreviated switches to single letters