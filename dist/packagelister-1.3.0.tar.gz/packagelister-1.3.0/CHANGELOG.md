# Changelog

## 1.2.0 (2023-04-12)

#### New Features

* add switch to add package versions with chosen relation when generating requirements.txt


## v1.1.3 (2023-03-22)

#### Others

* build v1.1.3


## v1.1.2 (2023-02-04)

#### Fixes

* (cli): change == to ~= when generating requirements.txt
#### Others

* update to build v1.1.2
* update changelog


## v1.1.1 (2023-01-25)

#### Fixes

* pyproject.toml indentation issue
#### Others

* build 1.1.1 dist files
* (cli): change abbreviated switches to single letters